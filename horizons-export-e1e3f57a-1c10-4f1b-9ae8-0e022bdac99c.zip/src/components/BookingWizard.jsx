import React from 'react';

const BookingWizard = () => {
  return (
    <div>
      <p>Este componente ha sido reemplazado por NewBookingWizard y será eliminado.</p>
    </div>
  );
};

export default BookingWizard;